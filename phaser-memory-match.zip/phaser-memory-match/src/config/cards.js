export const cards = {
  easy: {
    pairs: 4,
    cols: 4,
  },
  normal: {
    pairs: 6,
    cols: 6,
  },
  hard: {
    pairs: 9,
    cols: 6
  }
}